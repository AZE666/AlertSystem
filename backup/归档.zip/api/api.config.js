var dataapi_link="http://cmsdev.app-link.org/alucard263096/aze/api";//��д���Լ��������ķ�����������Ϣ


var apiconfig_beforeSend=function(XHR){
	var accesstoken=localStorage.accesstoken;
	if(!(accesstoken)){
		accesstoken=newGuid();
		//alert(accesstoken);
		localStorage.accesstoken=accesstoken;
	}
	XHR.setRequestHeader("accesstoken", accesstoken);
};

var apiconfig_complete=function(XHR, TS){
	//alert("co");
};
var newGuid=function()
{
    var guid = "";
    for (var i = 1; i <= 32; i++){
      var n = Math.floor(Math.random()*16.0).toString(16);
      guid +=   n;
      if((i==8)||(i==12)||(i==16)||(i==20))
        guid += "-";
    }
    return guid;    
};